export interface Regions {
    _id: string
    title: string
}

// Chercher toutes les régions > GET /region