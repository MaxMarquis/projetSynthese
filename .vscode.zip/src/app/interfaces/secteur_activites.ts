export interface Secteur_activites {
    _id: string,
    title: string
}
// Chercher tous les secteurs d’activités > GET /activity-sector

