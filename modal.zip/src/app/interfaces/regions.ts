export interface Regions {
    _id: String
    title: String
    updatedAt: Date
}

// Chercher toutes les régions > GET /region