import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-offres-stages',
  templateUrl: './offres-stages.component.html',
  styleUrls: ['./offres-stages.component.sass']
})
export class OffresStagesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
