export interface Regions {
    _id: String
    title: String
}

// Chercher toutes les régions > GET /region