export interface Secteur_activites {
    _id: String,
    title: String
}
// Chercher tous les secteurs d’activités > GET /activity-sector

