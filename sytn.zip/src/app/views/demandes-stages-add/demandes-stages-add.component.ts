import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-demandes-stages-add',
  templateUrl: './demandes-stages-add.component.html',
  styleUrls: ['./demandes-stages-add.component.sass']
})
export class DemandesStagesAddComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
