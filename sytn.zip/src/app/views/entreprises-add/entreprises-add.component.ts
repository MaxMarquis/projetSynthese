import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-entreprises-add',
  templateUrl: './entreprises-add.component.html',
  styleUrls: ['./entreprises-add.component.sass']
})
export class EntreprisesAddComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
